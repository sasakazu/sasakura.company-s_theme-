
<div class="sidebar">
  <h2>ウィジェットが入る</h2>
</div>
