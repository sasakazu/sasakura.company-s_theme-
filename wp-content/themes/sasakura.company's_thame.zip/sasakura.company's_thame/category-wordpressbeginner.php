

<?php get_header(); ?>


<div class="category-wp-begginer-header">
  <h1><i class="fab fa-wordpress-simple"></i>Wordpressビギナー</h1>
</div>

  <div class="container">


<div class="wp-beginner-wrapper">
  <h2>00.基本動作</h2>

  <div class="wp-beginner-inline">


  <div class="wp-beginner-img">
    <div class="bg-green">
      <img src="<?php bloginfo('template_directory'); ?>/images/wp_img.png" alt="">
      <!-- <h3>基本動作</h3> -->
    </div>

  </div>

  <div class="wp-beginner-list">
    <ul>
      <li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">Wordpressのテーマの追加</a></li>
      <li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">Wordpressのテーマの追加</a></li>
      <li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">Wordpressのテーマの追加</a></li>
      <li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">Wordpressのテーマの追加</a></li>
    </ul>

  </div>
</div>
</div>






</div>
<!-- container -->





<?php get_footer(); ?>
