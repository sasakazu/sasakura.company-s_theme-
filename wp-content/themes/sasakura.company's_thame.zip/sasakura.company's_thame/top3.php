<div class="more-wrapper">

  <!-- <h2 id="tutorial"><i class="fas fa-fire"></i>First Hack</h2> -->
  <div class="container">

    <ul class="more-colum">

      <li class="more-contents">
        <a href="/index.php?cat=2" class="more-img">
          <img src="<?php echo get_template_directory_uri(); ?>/images/wp_img.png" alt="">
        </a>
        <h2><a href="" id="more-title">Wordpressオリジナルテーマの作り方</a></h2>
        <a href="/index.php?cat=2" class="more-btn">Read More</a>
      </li>

      <li class="more-contents">
        <a href="#" class="more-img">
          <img src="<?php echo get_template_directory_uri(); ?>/images/comingsoon2.jpg" alt="">
        </a>
        <h2><a href="" id="more-title">iOSアプリの作り方</a></h2>
        <a href="#" class="more-btn">Comming Soon....</a>
      </li>

      <li class="more-contents">
        <a href="#" class="more-img">
          <img src="<?php echo get_template_directory_uri(); ?>/images/comingsoon2.jpg" alt="">
        </a>
        <h2><a href="" id="more-title">コンテンツSEOを極める</a></h2>
        <a href="/index.php?cat=2" class="more-btn">Comming Soon....</a>
      </li>




    </ul>


  </div>

</div>
