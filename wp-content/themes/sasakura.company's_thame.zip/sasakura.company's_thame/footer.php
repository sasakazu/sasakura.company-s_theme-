



<footer>
  ©️sasakura.company
</footer>

<?php wp_footer(); ?>
</body>

</html>
