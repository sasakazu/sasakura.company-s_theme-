
<footer class="footer-wrapper">
  <p>
    ©️sasakura.company
  </p>



</footer>

<?php wp_footer(); ?>
</body>

</html>
