<?php get_header(); ?>

<div class="google-ad">




		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- adse -->
<ins class="adsbygoogle"
     style="display:inline-block;width:970px;height:90px"
     data-ad-client="ca-pub-5047644305890156"
     data-ad-slot="9804120178"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>




<div class="category-wordpress-header">


  <h1><i class="fab fa-wordpress-simple"></i>Wordpressオリジナルテーマの作り方</h1>
</div>
  <div class="container">

<div class="preview-wp-site">
  <h2>完成品</h2>
  <div class="wp-step-inline">


  <a href="#" target="_blank">
    <img src="<?php bloginfo('template_directory'); ?>/images/image06.jpg" alt="" >
  </a>

</div>
</div>


<div class="wp-step-wrapper">
  <h2>00.開発準備</h2>

  <div class="wp-step-inline">


  <div class="wp-step-img">
    <div class="bg">
      <img src="<?php bloginfo('template_directory'); ?>/images/wp_img.png" alt="">

    </div>

  </div>

  <div class="wp-step-list">
    <ul>
      <li><i class="fas fa-angle-right"></i><a href="<?php echo get_permalink(2055); ?>" target= "_blank">はじめに</a></li>
      <li><i class="fas fa-angle-right"></i><a href="<?php echo get_permalink(2021); ?>" target= "_blank">MAMPのダウンロード方法</a></li>
      <li><i class="fas fa-angle-right"></i><a href="<?php echo get_permalink(2061); ?>" target= "_blank">MAMPの設定とWordPressの導入</a></li>
		<li><i class="fas fa-angle-right"></i><a href="<?php echo get_permalink(2112); ?>" target="_blank">GitHubのアカウント登録とレポジトリの作成方法</a></li>
    </ul>

  </div>
</div>
</div>

<div class="wp-step-wrapper">


  <h2>01.フロントページ</h2>

  <div class="wp-step-inline">


  <div class="wp-step-img">
    <div class="bg">
      <img src="<?php bloginfo('template_directory'); ?>/images/wp_img.png" alt="">

    </div>

  </div>

  <div class="wp-step-list">
    <ul>
		<li><i class="fas fa-angle-right"></i><a href="<?php echo get_permalink(2143); ?>" target= "_blank">ワードプレスカスタマイズテーマの下準備</a></li>
		<li><i class="fas fa-angle-right"></i><a href="<?php echo get_permalink(2161); ?>" target= "_blank">リセットCSSの追加</a></li>
		<li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">ナビゲーションメニューの作成</a></li>
		<li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">トップヘッダーの作成</a></li>
		<li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">新着一覧の作成</a></li>
		<li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">サイドバーの作成</a></li>

    </ul>

  </div>
</div>
</div>

<!-- <hr> -->

<div class="wp-step-wrapper">
  <h2>02.シングルページ</h2>

  <div class="wp-step-inline">


  <div class="wp-step-img">
    <div class="bg">
      <img src="<?php bloginfo('template_directory'); ?>/images/wp_img.png" alt="">

    </div>

  </div>

  <div class="wp-step-list">
    <ul>
      <li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">シングルページを作成</a></li>

    </ul>

  </div>
 </div>


</div>


<div class="wp-step-wrapper">
  <h2>03.コンタクトページ</h2>

  <div class="wp-step-inline">


  <div class="wp-step-img">
    <div class="bg">
      <img src="<?php bloginfo('template_directory'); ?>/images/wp_img.png" alt="">

    </div>

  </div>

  <div class="wp-step-list">
    <ul>
      <li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">プラグイン「Contact form7」の導入・設定</a></li>
      <li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">レイアウトを整える</a></li>
      <li><i class="fas fa-angle-right"></i><a href="#" target= "_blank">プラグイン「Contact form7」の導入</a></li>

    </ul>

  </div>
 </div>


</div>











</div>
<!-- container -->





<?php get_footer(); ?>



<!--  リスト
00
・MAMPの導入
・Githubの登録
・必須ファイルの作成
・レイアウトの決定
・
・
・
・
・
・

01フロントページ
・ナブメニューの作成
・slickでクロスフェード
・
・
・
・
02サイドバー
・
・
・


01フロントページ
01フロントページ
01フロントページ
01フロントページ
01フロントページ
01フロントページ




-->
